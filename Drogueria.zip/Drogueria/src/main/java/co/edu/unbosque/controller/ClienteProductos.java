package co.edu.unbosque.controller;

import java.util.ArrayList;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import co.edu.unbosque.model.entity.Auditoria;
import co.edu.unbosque.model.entity.Cliente;
import co.edu.unbosque.model.entity.Producto;
import co.edu.unbosque.model.service.AuditoriaService;
import co.edu.unbosque.model.service.ProductoService;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
@ManagedBean
@SessionScoped
public class ClienteProductos {
	
	
	private AuditoriaService audiser = new AuditoriaService();
	private ProductoService productServ = new ProductoService();
	private ArrayList<Producto> productos;
	private Cliente usuario;
	private ArrayList<Producto> canasta;
	private Producto producto;
	private String login;
	private String password;
	
	public ClienteProductos() {
		// TODO Auto-generated constructor stub
		
	}
	
	public void comprar() {
		
        
        if (!canasta.isEmpty()) {
            
        	String filePath = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/resources/compras.txt");

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(new File(filePath), true))) {
                
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                for (Producto product : canasta) {
                    String fechaDeCompra = String.format("%s - %s - %.2f",
                            product.getNmbreElemnto(), dateFormat.format(new Date()), product.getPrcioVntaAc());
                    writer.write(fechaDeCompra);
                    writer.newLine();
                }

                
                canasta.clear();
            } catch (IOException e) {
            	System.out.println("no funciono");
                e.printStackTrace();
            }
        }
    }

	
	public void addProducto(Producto producto) {
	    if (producto != null && producto.getCntdadElemnto() > 0) {
	    	producto.setCntdadElemnto(producto.getCntdadElemnto() - 1);
	    	productServ.update(producto);
	    	DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        String formattedDate = dateFormat.format(new Date());

	        // Create a File object for the text file
	        File file = new File("C:\\Users\\ASUS\\Desktop\\ProyectosReales\\Drogueria\\compras.txt");
	        AuditoriaService as = new AuditoriaService();
	        Auditoria a = new Auditoria("C", "clientehomepage.xhtml", producto.getCdgoElemnto() + " ha sido comprado", new Date(), "Cliente");
	        as.create(a);
	        try {
	            
	            if (!file.exists()) {
	                file.createNewFile();
	            }

	            FileWriter fileWriter = new FileWriter(file, true);
	            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

	            
	            bufferedWriter.write(producto.getNmbreElemnto() + ", " + formattedDate + ", " + producto.getPrcioVntaAc() + ", " + producto.getCstoVnta());
	            bufferedWriter.newLine(); 

	            
	            bufferedWriter.close();

	            System.out.println("Compra agregada exitosamente!.");
	            FacesContext.getCurrentInstance().addMessage(null,
	                    new FacesMessage(FacesMessage.SEVERITY_INFO, "Compra agregada exitosamente!", null));

	            
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	    } else {
	        FacesContext.getCurrentInstance().addMessage(null,
	                new FacesMessage(FacesMessage.SEVERITY_WARN, "Producto agotado", null));
	        // O la vista actual si no se redirige a ninguna página
	    }
	}
	public static void updateFile(Producto producto) {
        // Format the date
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String formattedDate = dateFormat.format(new Date());

        // Create a File object for the text file
        File file = new File("compras.txt");

        try {
            
            if (!file.exists()) {
                file.createNewFile();
            }

            FileWriter fileWriter = new FileWriter(file, true);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            
            bufferedWriter.write(producto.getNmbreElemnto() + ", " + formattedDate + ", " + producto.getPrcioVntaAc() + ", " + producto.getCstoVnta());
            bufferedWriter.newLine(); 

            
            bufferedWriter.close();

            System.out.println("Data written to the file successfully.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


	
	public String logout() {
	    FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
	    setLogin("");
	    setPassword("");
	    canasta.clear();
	    return "index.xhtml";
	}
	
	
	public AuditoriaService getAudiser() {
		return audiser;
	}
	public void setAudiser(AuditoriaService audiser) {
		this.audiser = audiser;
	}
	public ArrayList<Producto> getProductos() {
		canasta = new ArrayList<Producto>();
		ProductoService proser = new ProductoService();
		productos = (ArrayList<Producto>) proser.findAll();
		return productos;
	}
	public void setProductos(ArrayList<Producto> productos) {
		this.productos = productos;
	}
	public Cliente getUsuario() {
		return usuario;
	}
	public void setUsuario(Cliente usuario) {
		this.usuario = usuario;
	}
	public ArrayList<Producto> getCanasta() {
	    return canasta;
	}
	public void setCanasta(ArrayList<Producto> canasta) {
		this.canasta = canasta;
	}

	public Producto getProducto() {
		return producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
