package co.edu.unbosque.model.dao;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import co.edu.unbosque.model.entity.Auditoria;
import co.edu.unbosque.model.entity.Cliente;
import co.edu.unbosque.model.entity.Producto;
import co.edu.unbosque.model.entity.Tipousuario;
import co.edu.unbosque.model.entity.Usuario;

public class HibernateUtil {
//
//	 private static SessionFactory sessionFactory;
//
//	    public HibernateUtil() {
//	    }
//
//	    public static SessionFactory getSessionFactory() {
//	        if (sessionFactory == null) {
//	        	try {
//	        		Configuration configuration = new Configuration();
//	        		configuration.configure("/hibernate.cfg.xml");
//	        		sessionFactory = configuration.buildSessionFactory();
//					
//				} catch (Exception e) {
//					System.err.println(e);
//				}
//	        }
//	        return sessionFactory;
//	    }
	private static SessionFactory sessionFactory;

	private HibernateUtil() {
	}

	@SuppressWarnings("deprecation")
	public static SessionFactory getSessionFactory() {

		if (sessionFactory == null) {
			try {
				@SuppressWarnings("deprecation")
				Configuration ac = new Configuration();
				ac.addAnnotatedClass(Usuario.class);
				ac.addAnnotatedClass(Auditoria.class);
				ac.addAnnotatedClass(Cliente.class);
				ac.addAnnotatedClass(Tipousuario.class);
				ac.addAnnotatedClass(Producto.class);
				sessionFactory = ac.configure().buildSessionFactory();

			} catch (Throwable ex) {
				// Log the exception.
				System.err.println("Initial SessionFactory creation failed." + ex);
				throw new ExceptionInInitializerError(ex);
			}
			return sessionFactory;
		} else {
			return sessionFactory;
		}
	}

}
