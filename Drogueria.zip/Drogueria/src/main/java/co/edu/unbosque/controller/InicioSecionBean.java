package co.edu.unbosque.controller;


import java.util.*;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import co.edu.unbosque.model.dao.MandarCorreo;
import co.edu.unbosque.model.entity.Auditoria;
import co.edu.unbosque.model.entity.Cliente;
import co.edu.unbosque.model.entity.Usuario;
import co.edu.unbosque.model.service.AuditoriaService;
import co.edu.unbosque.model.service.ClienteService;
import co.edu.unbosque.model.service.UsuarioService;

@ManagedBean
@SessionScoped
public class InicioSecionBean {
	
	private AuditoriaService auditoria;
	private String login;
	private String password;
	
	
//	public static void main(String[] args) {
//		login = "123";
//		password = "123456789";
//		verificarTipoUsuario();
//		
//	}

	public String logout() {
	    FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
	    login = "";
	    password = "";
	    return "index.xhtml";
	}
	
	public String verificarTipoUsuario() {
		UsuarioService usuarioser = new UsuarioService();
		ClienteService clienteser = new ClienteService();
		System.out.println(login);
		System.out.println(password);
	    Usuario usuario = usuarioser.findById(login);
	    ArrayList<Cliente> cliente = (ArrayList<Cliente>) clienteser.findAll();
	    System.out.println(usuario);
	    Auditoria audi= new Auditoria();
	    auditoria = new AuditoriaService();
	    
	    if (usuario != null && usuario.getClave().equals(password)) {
	    	if (usuario.getTipoUsuario() == 1) {
	        	System.out.println("adminpage");
	        	audi.setAccionAudtria("INICIO SECCION");
	        	audi.setAddressAudtria("INICIO SECCION index.xhtml");
	        	audi.setComentarioAudtria(usuario.getLogin()+" HA INGRESADO EN EL SISTEMA");
	        	audi.setFchaAudtria(new Date());
	        	audi.setUsrioAudtria(usuario.getNombreUsuario()+" "+usuario.getApellidoUsuario());
	        	usuario.setFechaUltimoIngreso(new Date());
	        	usuarioser.update(usuario);
	        	auditoria.create(audi);
	        	
	            return "adminhomepage.xhtml";
	        }
	    }else {
	    	FacesContext.getCurrentInstance().addMessage("form", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Usuario o contraseña incorrectos"));
	    }
	    
	    if (usuario != null && usuario.getClave().equals(usuarioser.codificarContasena(password))) {
	        if (usuario.getTipoUsuario() == 3) {
	        	System.out.println("homepage");
	        	audi.setAccionAudtria("INICIO SECCION");
	        	audi.setAddressAudtria("INICIO SECCION index.xhtml");
	        	audi.setComentarioAudtria(usuario.getLogin()+" HA INGRESADO EN EL SISTEMA");
	        	audi.setFchaAudtria(new Date());
	        	audi.setUsrioAudtria(usuario.getNombreUsuario()+" "+usuario.getApellidoUsuario());
	        	usuario.setFechaUltimoIngreso(new Date());
	        	usuarioser.update(usuario);
	        	auditoria.create(audi);
	            return "clientehomepage.xhtml";
	        }
	    }else {
	    	String correo = "";
	    	String nombre = "";
        	if(usuario.getIntentos() >= 3) {
        		for (int i = 0; i < cliente.size(); i++) {
    	    		if(cliente.get(i).getNombre().equals(login)) {
    	    			correo = cliente.get(i).getCorreo();
    	    			nombre = cliente.get(i).getNombre();
    	    		}
    			}
	    		MandarCorreo mandar = new MandarCorreo();
	    		mandar.correo(nombre, correo, "http://localhost:8080/Drogueria/habilitar.xhtml");
	    		System.out.println("CORREO ENVIADO");
	    	}else {
	    		FacesContext.getCurrentInstance().addMessage("form", new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Usuario o contraseña incorrectos"));
		    	System.out.println("no funciona");
		    	usuario.setIntentos((short) (usuario.getIntentos()+1));
		    	usuarioser.update(usuario);
		        return "error";
	    	}
        }
	    return null;
	}
	
	
	public String habilitado()
	{
		UsuarioService usuarioser = new UsuarioService();
	    Usuario usuario = usuarioser.findById(login);
		if(usuario != null) {
			usuario.setIntentos((short) 0);
			usuarioser.update(usuario);
			return "index.xhtml";
		}else {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Usuario no encontrado"));
		}
		return null;
	}
	
	public String registro() {
		return "CrearCuenta.xhtml";
	}
	
	public AuditoriaService getAuditoria() {
		return auditoria;
	}
	public void setAuditoria(AuditoriaService auditoria) {
		this.auditoria = auditoria;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	

}
