package co.edu.unbosque.model.dao;

import co.edu.unbosque.model.entity.Usuario;

public class UsuarioDAO extends GenericDAO<Usuario, String>{

	public UsuarioDAO() {
		super(Usuario.class);
		// TODO Auto-generated constructor stub
	}

}
