package co.edu.unbosque.validator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("userValidator")
public class User implements Validator {

	private static final int DEFAULT_MIN_LENGTH = 3;
	private static final int DEFAULT_MAX_LENGTH = 20;

	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		int minLength = DEFAULT_MIN_LENGTH;
		int maxLength = DEFAULT_MAX_LENGTH;

		String stringValue = (value == null) ? "" : value.toString().trim();
		int length = stringValue.length();

		if (length < minLength || length > maxLength) {
			throw new ValidatorException(new FacesMessage(FacesMessage
					.SEVERITY_ERROR,
					"El campo debe tener entre " + minLength + " y " + maxLength + " caracteres.", null));
		}
	}
}
