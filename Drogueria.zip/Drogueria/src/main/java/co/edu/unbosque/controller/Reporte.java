package co.edu.unbosque.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

import org.primefaces.PrimeFaces;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


import co.edu.unbosque.model.entity.Cliente;
import co.edu.unbosque.model.entity.Producto;
import co.edu.unbosque.model.service.ClienteService;
import co.edu.unbosque.model.service.ProductoService;
import com.itextpdf.text.Chunk;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

@ManagedBean
@RequestScoped
public class Reporte {

	private boolean producto;
	private boolean cliente;
	private boolean venta;
	private boolean ganancia;
	private boolean perdida;
	private boolean eliminado;

	public Reporte() {
		// TODO Auto-generated constructor stub
	}

	public void generarReporte() {
		Document document = new Document();
		try {
			System.out.println(producto);
			System.out.println(cliente);
			System.out.println(venta);
			System.out.println(ganancia);
			System.out.println(perdida);
			System.out.println(eliminado);
			//String rutaPDF = FacesContext.getCurrentInstance().getExternalContext().getRealPath("/Estadisticas.pdf");
			File rutaPDF = new File("C:\\Users\\ASUS\\Desktop\\ProyectosReales\\Drogueria\\Estadisticas.pdf");
			System.out.println(rutaPDF);
			PdfWriter.getInstance(document, new FileOutputStream(rutaPDF));
			document.open();

			faltantes(document);
			
			ganancias(document);
			
			eliminados(document);

			
			
			

			System.out.println("PDF creado con exito");
		} catch (DocumentException | IOException e) {
			e.printStackTrace();
		}finally {
            if (document != null && document.isOpen()) {
                document.close();
                //mostrarPDF("C:\\Users\\ASUS\\Desktop\\ProyectosReales\\Drogueria\\Estadisticas.pdf");
                //return "/Estadisticas.pdf";
            }
        }
		//return null;
		
		PrimeFaces.current().executeScript("window.open('C:\\Users\\ASUS\\Desktop\\ProyectosReales\\Drogueria\\Estadisticas.pdf')");
		
	}
	
	public void mostrarPDF(String ruta) {
		PdfReader reader;

        try {

            reader = new PdfReader(ruta);

            System.out.println("aqui estoy");
            String textFromPage = PdfTextExtractor.getTextFromPage(reader, 1);

            System.out.println(textFromPage);

            reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }
	
	
	public void eliminados(Document document) {
		if (eliminado) {
			
			ClienteService cliser = new ClienteService();
			ArrayList<Cliente> clientes = (ArrayList<Cliente>) cliser.findAll();
			try {
				document.add(new Paragraph("Lista de Usuarios Eliminados:\n\n\n"));

				PdfPTable tabla = new PdfPTable(3);
				tabla.addCell("Usuario");
				tabla.addCell("Correo");
				tabla.addCell("Identificacion");
				for (Cliente i : clientes) {
					if (i.getEstado().equals("I")) {
						tabla.addCell(i.getNombre());
						tabla.addCell(i.getCorreo());
						tabla.addCell(i.getIdentificacion());
					}
				}
				document.add(tabla);
				System.out.println("Eliminados Generado");
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}
	
	public void faltantes(Document document) {
		if(producto) {
			ProductoService proser = new ProductoService();
			ArrayList<Producto> faltantes = (ArrayList<Producto>) proser.findAll();
			
			try {
				document.add(new Paragraph("\nLista de productos sin stock:\n\n\n"));
			PdfPTable tablaProductos = new PdfPTable(4);
			tablaProductos.addCell("Codigo Producto");
			tablaProductos.addCell("Nombre Producto");
			tablaProductos.addCell("Cantidad");
			tablaProductos.addCell("Precio");
			for (Producto i : faltantes) {
				if (i.getCntdadElemnto() <= i.getStockMinmo()) {
					tablaProductos.addCell(i.getCdgoElemnto());
					tablaProductos.addCell(i.getNmbreElemnto());
					tablaProductos.addCell(i.getCntdadElemnto() + "");
					tablaProductos.addCell(i.getCstoVnta() + "");
				}
			}
			document.add(tablaProductos);
			System.out.println("Faltantes generado");
			} catch (DocumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	public void ganancias(Document document) {
	    if (ganancia) {
	        try {
	            document.add(new Paragraph("\nEstado de Perdidas y Ganancias:\n\n\n"));

	            // Read the content from the file
	            String filePath = "C:\\Users\\ASUS\\Desktop\\ProyectosReales\\Drogueria\\compras.txt";
	            List<String> lines = Files.readAllLines(Paths.get(filePath), StandardCharsets.UTF_8);

	            // Create a table to display the information
	            PdfPTable table = new PdfPTable(4);
	            table.addCell("Nombre");
	            table.addCell("Fecha Compra");
	            table.addCell("Precio Venta");
	            table.addCell("Precio Compra");

	            // Variables to calculate total gains
	            double totalPrecioVenta = 0;
	            double totalPrecioCompra = 0;

	            // Parse each line and add it to the table
	            for (String line : lines) {
	                String[] parts = line.split(", ");
	                String nombre = parts[0];
	                String fechaCompra = parts[1];
	                double precioVenta = Double.parseDouble(parts[2]);
	                double precioCompra = Double.parseDouble(parts[3]);

	                table.addCell(nombre);
	                table.addCell(fechaCompra);
	                table.addCell(String.valueOf(precioVenta));
	                table.addCell(String.valueOf(precioCompra));

	                totalPrecioVenta += precioVenta;
	                totalPrecioCompra += precioCompra;
	            }

	            // Add the table to the document
	            document.add(table);

	            // Display the totals
	            document.add(new Paragraph("\nTotal Precio Venta: " + totalPrecioVenta));
	            document.add(new Paragraph("Total Precio Compra: " + totalPrecioCompra));
	            document.add(new Paragraph("Total Ganancia: " + (totalPrecioVenta - totalPrecioCompra)));

	            System.out.println("Ganancias generado");
	        } catch (DocumentException | IOException e) {
	            e.printStackTrace();
	        }
	    }
	}
	
	
	
	

	public boolean isProducto() {
		return producto;
	}

	public void setProducto(boolean producto) {
		this.producto = producto;
	}

	public boolean isCliente() {
		return cliente;
	}

	public void setCliente(boolean cliente) {
		this.cliente = cliente;
	}

	public boolean isVenta() {
		return venta;
	}

	public void setVenta(boolean venta) {
		this.venta = venta;
	}

	public boolean isGanancia() {
		return ganancia;
	}

	public void setGanancia(boolean ganancia) {
		this.ganancia = ganancia;
	}

	public boolean isPerdida() {
		return perdida;
	}

	public void setPerdida(boolean perdida) {
		this.perdida = perdida;
	}

	public boolean isEliminado() {
		return eliminado;
	}

	public void setEliminado(boolean eliminado) {
		this.eliminado = eliminado;
	}
	
	

}
