package co.edu.unbosque.model.entity;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;




/**
 * The persistent class for the producto database table.
 * 
 */
@Entity
@Table(name="producto", uniqueConstraints = @UniqueConstraint(columnNames = "cdgo_elemnto"))
public class Producto implements Serializable {
	private static final long serialVersionUID = 1L;
	

	@Id
	@Column(name="cdgo_elemnto")
	private String cdgoElemnto;

	@Column(name="cntdad_elemnto")
	private int cntdadElemnto;

	@Column(name="csto_vnta")
	private int cstoVnta;

	@Column(name="ctgria_elemnto")
	private short ctgriaElemnto;

	@Column(name="estdo_elemnto")
	private String estdoElemnto;

	@Column(name="iva_elemnto")
	private String ivaElemnto;

	@Column(name="mrgen_utldad")
	private double mrgenUtldad;

	@Column(name="nmbre_elemnto")
	private String nmbreElemnto;

	@Column(name="prcio_vnta_ac")
	private int prcioVntaAc;

	@Column(name="prcio_vnta_an")
	private int prcioVntaAn;

	@Column(name="stock_minmo")
	private short stockMinmo;

	@Column(name="stock_mxmo")
	private short stockMxmo;

	@Column(name="und_elemnto")
	private short undElemnto;
	
	@Column(name="url")
	private String url;

	public Producto() {
	}

	public Producto(String cdgoElemnto, int cntdadElemnto, int cstoVnta, short ctgriaElemnto, String estdoElemnto,
			String ivaElemnto, double mrgenUtldad, String nmbreElemnto, int prcioVntaAc, int prcioVntaAn,
			short stockMinmo, short stockMxmo, short undElemnto, String url) {
		super();
		this.cdgoElemnto = cdgoElemnto;
		this.cntdadElemnto = cntdadElemnto;
		this.cstoVnta = cstoVnta;
		this.ctgriaElemnto = ctgriaElemnto;
		this.estdoElemnto = estdoElemnto;
		this.ivaElemnto = ivaElemnto;
		this.mrgenUtldad = mrgenUtldad;
		this.nmbreElemnto = nmbreElemnto;
		this.prcioVntaAc = prcioVntaAc;
		this.prcioVntaAn = prcioVntaAn;
		this.stockMinmo = stockMinmo;
		this.stockMxmo = stockMxmo;
		this.undElemnto = undElemnto;
		this.url = url;
	}

	public String getCdgoElemnto() {
		return cdgoElemnto;
	}

	public void setCdgoElemnto(String cdgoElemnto) {
		this.cdgoElemnto = cdgoElemnto;
	}

	public int getCntdadElemnto() {
		return cntdadElemnto;
	}

	public void setCntdadElemnto(int cntdadElemnto) {
		this.cntdadElemnto = cntdadElemnto;
	}

	public int getCstoVnta() {
		return cstoVnta;
	}

	public void setCstoVnta(int cstoVnta) {
		this.cstoVnta = cstoVnta;
	}

	public short getCtgriaElemnto() {
		return ctgriaElemnto;
	}

	public void setCtgriaElemnto(short ctgriaElemnto) {
		this.ctgriaElemnto = ctgriaElemnto;
	}

	public String getEstdoElemnto() {
		return estdoElemnto;
	}

	public void setEstdoElemnto(String estdoElemnto) {
		this.estdoElemnto = estdoElemnto;
	}

	public String getIvaElemnto() {
		return ivaElemnto;
	}

	public void setIvaElemnto(String ivaElemnto) {
		this.ivaElemnto = ivaElemnto;
	}

	public double getMrgenUtldad() {
		return mrgenUtldad;
	}

	public void setMrgenUtldad(double mrgenUtldad) {
		this.mrgenUtldad = mrgenUtldad;
	}

	public String getNmbreElemnto() {
		return nmbreElemnto;
	}

	public void setNmbreElemnto(String nmbreElemnto) {
		this.nmbreElemnto = nmbreElemnto;
	}

	public int getPrcioVntaAc() {
		return prcioVntaAc;
	}

	public void setPrcioVntaAc(int prcioVntaAc) {
		this.prcioVntaAc = prcioVntaAc;
	}

	public int getPrcioVntaAn() {
		return prcioVntaAn;
	}

	public void setPrcioVntaAn(int prcioVntaAn) {
		this.prcioVntaAn = prcioVntaAn;
	}

	public short getStockMinmo() {
		return stockMinmo;
	}

	public void setStockMinmo(short stockMinmo) {
		this.stockMinmo = stockMinmo;
	}

	public short getStockMxmo() {
		return stockMxmo;
	}

	public void setStockMxmo(short stockMxmo) {
		this.stockMxmo = stockMxmo;
	}

	public short getUndElemnto() {
		return undElemnto;
	}

	public void setUndElemnto(short undElemnto) {
		this.undElemnto = undElemnto;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	@Override
	public String toString() {
		return "Producto [cdgoElemnto=" + cdgoElemnto + ", cntdadElemnto=" + cntdadElemnto + ", cstoVnta=" + cstoVnta
				+ ", ctgriaElemnto=" + ctgriaElemnto + ", estdoElemnto=" + estdoElemnto + ", ivaElemnto=" + ivaElemnto
				+ ", mrgenUtldad=" + mrgenUtldad + ", nmbreElemnto=" + nmbreElemnto + ", prcioVntaAc=" + prcioVntaAc
				+ ", prcioVntaAn=" + prcioVntaAn + ", stockMinmo=" + stockMinmo + ", stockMxmo=" + stockMxmo
				+ ", undElemnto=" + undElemnto + ", url=" + url + "]";
	}
	
	
	
	

}