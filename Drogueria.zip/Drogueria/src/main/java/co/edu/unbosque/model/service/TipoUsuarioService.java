package co.edu.unbosque.model.service;

import java.util.List;

import co.edu.unbosque.model.dao.TipoUsuarioDAO;
import co.edu.unbosque.model.entity.Tipousuario;

public class TipoUsuarioService implements Service<Tipousuario, Short>{

	private TipoUsuarioDAO tipousuariodao;
	
	public TipoUsuarioService() {
		this.tipousuariodao = new TipoUsuarioDAO();
	}
	
	@Override
	public void create(Tipousuario objeto) {
		tipousuariodao.saveOrUpdate(objeto);
	}

	@Override
	public void update(Tipousuario objeto) {
		tipousuariodao.saveOrUpdate(objeto);
	}

	@Override
	public Tipousuario delete(Tipousuario objeto) {
		Tipousuario tipousuarioaux = objeto;
		tipousuarioaux.setEstado("I");
		tipousuariodao.delete(tipousuarioaux);
		return objeto;
	}

	@Override
	public Tipousuario findById(Short id) {
		return tipousuariodao.get(id);
	}

	@Override
	public List<Tipousuario> findAll() {
		return tipousuariodao.findAll();
	}
	
	

}
