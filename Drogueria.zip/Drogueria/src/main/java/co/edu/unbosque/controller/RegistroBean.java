package co.edu.unbosque.controller;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import co.edu.unbosque.model.dao.MandarCorreo;
import co.edu.unbosque.model.entity.Auditoria;
import co.edu.unbosque.model.entity.Cliente;
import co.edu.unbosque.model.entity.Usuario;
import co.edu.unbosque.model.service.AuditoriaService;
import co.edu.unbosque.model.service.ClienteService;
import co.edu.unbosque.model.service.UsuarioService;

@ManagedBean
@SessionScoped
public class RegistroBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Cliente cliente = new Cliente();
	private Usuario user = new Usuario();
	private Auditoria auditoria = new Auditoria();
	private static String login = "";
	private static String contraseña1 = "";
	private static String contraseña2 = "";
	private AuditoriaService auditoriaser = new AuditoriaService();
	private ClienteService clienteser = new ClienteService();
	private UsuarioService userser = new UsuarioService();
	private MandarCorreo correo = new MandarCorreo();
	
	
	public RegistroBean() {
		// TODO Auto-generated constructor stub
	}
	 
	
	public String crearUsuario() {
		
		System.out.println(login);
		Usuario aux = userser.findById(login);
		System.out.println(aux);
		if(aux == null) {
			if(contraseña1.equals(contraseña2)) {
//				cliente();
				cliente.setComprasMes(new BigDecimal(0));
				cliente.setCupocredito(new BigDecimal(0));
				cliente.setEstado("A");
				cliente.setPagosMes(new BigDecimal(0));
				cliente.setSaldoActual(new BigDecimal(0));
//				usuario();
				user.setEstado("A");
				user.setFechaUltimaClave(new Date());
				user.setIntentos((short)3);
				user.setTipoUsuario((short)3);
//				auditoria();
				auditoria.setAccionAudtria("REGISTRO CLIENTE");
				auditoria.setAddressAudtria("Registro cliente CrearCuenta.xhtml");
				auditoria.setFchaAudtria(new Date());
				
				user.setLogin(login);
				user.setClave(userser.codificarContasena(contraseña1));
				user.setNombreCorto(login);
				cliente.setNombre(user.getLogin());
				auditoria.setUsrioAudtria(user.getNombreUsuario()+" "+user.getApellidoUsuario());
				auditoria.setComentarioAudtria(user.getNombreCorto()+" se ha registrado en el sistema");
				clienteser.create(cliente);
				userser.create(user);
				auditoriaser.create(auditoria);
				correo.correo2(login, cliente.getCorreo(), "http://localhost:8080/Drogueria/index.xhtml");
				return "index.xhtml";
			}else {
				System.out.println("contraseña no coincide");
				 FacesContext.getCurrentInstance().addMessage(null,
		                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Las contraseñas no coinciden."));
		            return null; 
			}
		}else {
			System.out.println("El user ya existe");
			FacesContext.getCurrentInstance().addMessage(null, 
	                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "El usuario ya existe. Por favor, elige otro login."));
		}
		return null;
	}
	public void cliente() {
		cliente.setComprasMes(new BigDecimal(0));
		cliente.setCupocredito(new BigDecimal(0));
		cliente.setEstado("A");
		cliente.setPagosMes(new BigDecimal(0));
		cliente.setSaldoActual(new BigDecimal(0));
	}
	public void usuario() {
		user.setEstado("A");
		user.setFechaUltimaClave(new Date());
		user.setIntentos((short)3);
		user.setTipoUsuario((short)3);
	}
	public void auditoria() {
		auditoria.setAccionAudtria("REGISTRO CLIENTE");
		auditoria.setAddressAudtria("Registro cliente CrearCuenta.xhtml");
		auditoria.setFchaAudtria(new Date());
		
		
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Usuario getUser() {
		return user;
	}
	public void setUser(Usuario user) {
		this.user = user;
	}
	public Auditoria getAuditoria() {
		return auditoria;
	}
	public void setAuditoria(Auditoria auditoria) {
		this.auditoria = auditoria;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getContraseña1() {
		return contraseña1;
	}
	public void setContraseña1(String contraseña1) {
		this.contraseña1 = contraseña1;
	}
	public String getContraseña2() {
		return contraseña2;
	}
	public void setContraseña2(String contraseña2) {
		this.contraseña2 = contraseña2;
	}
	public AuditoriaService getAuditoriaser() {
		return auditoriaser;
	}
	public void setAuditoriaser(AuditoriaService auditoriaser) {
		this.auditoriaser = auditoriaser;
	}
	public ClienteService getClienteser() {
		return clienteser;
	}
	public void setClienteser(ClienteService clienteser) {
		this.clienteser = clienteser;
	}
	public UsuarioService getUserser() {
		return userser;
	}
	public void setUserser(UsuarioService userser) {
		this.userser = userser;
	}
	
	
	

}
