package co.edu.unbosque.model.dao;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MandarCorreo {

	public String correo(String nombre, String correo,  String link) {

		String username = "sophysdrogueria@gmail.com";
		String password = "cerm vvxn iswp enlo";
		boolean enviado = false;

		Properties prop = new Properties();
		prop.put("mail.smtp.host", "smtp.gmail.com");
		prop.put("mail.smtp.port", "587");
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.starttls.enable", "true"); // TLS

		Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("sophysdrogueria@gmail.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correo));
			message.setSubject("Importante: Bloqueo de Cuenta - Acción Urgente Requerida");
			message.setText("Estimado/a " + nombre + ",\r\n"
					+ "\r\n"
					+ "Esperamos que este mensaje le encuentre bien. Lamentamos informarle que hemos detectado actividades inusuales en su cuenta, lo que ha llevado a una medida preventiva de seguridad: el bloqueo temporal de su cuenta.\r\n"
					+ "\r\n"
					+ "*Detalles del Bloqueo:*\r\n"
					+ "- Razón del Bloqueo: Actividad sospechosa detectada.\r\n"
					+ "\r\n"
					+ "*Acción Requerida:*\r\n"
					+ "Para reactivar su cuenta de inmediato y evitar cualquier inconveniente en el acceso, le instamos a seguir el enlace proporcionado a continuación. Este enlace lo llevará a través de un proceso de verificación para restablecer el acceso a su cuenta de manera segura.\r\n"
					+ "\r\n"
					+ link +"\r\n"
					+ "\r\n"
					+ "Por favor, tenga en cuenta que este enlace es válido por un tiempo limitado. Si no completa el proceso de reactivación dentro de este período, su cuenta podría permanecer bloqueada temporalmente o, en última instancia, ser suspendida por razones de seguridad.\r\n"
					+ "\r\n"
					+ "*Consejos de Seguridad:*\r\n"
					+ "- Nunca comparta su información de inicio de sesión con terceros.\r\n"
					+ "- Utilice contraseñas seguras y actualícelas periódicamente.\r\n"
					+ "- Monitoree regularmente su cuenta en busca de actividad no autorizada.\r\n"
					+ "\r\n"
					+ "Agradecemos su pronta atención a este asunto.\r\n"
					+ "\r\n"
					+ "Gracias por su cooperación.\r\n"
					+ "\r\n"
					+ "Atentamente,\r\n"
					+ "\r\n"
					+ "[Servicios S.A.S]\r\n"
					+ "Equipo de Soporte de [Droguerias SOPHY´s]");

			Transport.send(message);

			enviado = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (enviado) {
			return ("Mensaje enviado exitosamente");
		} else {
			return ("Mensaje no fue enviado");
		}
	}
	
	public String correo2(String nombre, String correo,  String link) {

		String username = "sophysdrogueria@gmail.com";
		String password = "cerm vvxn iswp enlo";
		boolean enviado = false;

		Properties prop = new Properties();
		prop.put("mail.smtp.host", "smtp.gmail.com");
		prop.put("mail.smtp.port", "587");
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.starttls.enable", "true"); // TLS

		Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("sophysdrogueria@gmail.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(correo));
			message.setSubject("Importante: Bloqueo de Cuenta - Acción Urgente Requerida");
			message.setText("¡Saludos!\r\n"
					+ "\r\n"
					+ "Nos complace informarte que tu registro en nuestro servicio se ha completado con éxito. ¡Bienvenido/a a nuestra comunidad!\r\n"
					+ "\r\n"
					+ "*Detalles de Registro:*\r\n"
					+ "- Nombre de Usuario: "+ nombre +"\r\n"
					+ "- Dirección de Correo Electrónico:"+ correo +"\r\n"
					+ "\r\n"
					+ "Estamos emocionados de tenerte como parte de nuestra plataforma. Aquí algunos puntos importantes para empezar:\r\n"
					+ "\r\n"
					+ "- Explora todas las funciones que ofrecemos y descubre cómo sacar el máximo provecho de nuestra plataforma.\r\n"
					+ "- Mantén tu información de inicio de sesión de forma segura y no la compartas con nadie.\r\n"
					+ "- Siempre estamos aquí para ayudarte. No dudes en contactar a nuestro equipo de soporte en caso de cualquier consulta o problema.\r\n"
					+ "\r\n"
					+ "¡Gracias por unirte a nosotros y ser parte de esta experiencia!\r\n"
					+ "\r\n"
					+ "Atentamente,\r\n"
					+ "\r\n"
					+ "Presiona aqui para volver,\r\n"
					+ "\r\n"
					+ link + "\r\n"
					+ "\r\n"
					+ "[Servicios S.A.S]\r\n"
					+ "Equipo de Soporte de [Droguerias SOPHY´s]");

			Transport.send(message);

			enviado = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (enviado) {
			return ("Mensaje enviado exitosamente");
		} else {
			return ("Mensaje no fue enviado");
		}
	}
	
}