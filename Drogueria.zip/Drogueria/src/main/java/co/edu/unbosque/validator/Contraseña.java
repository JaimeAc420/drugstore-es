package co.edu.unbosque.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("passwordValidator")
public class Contraseña implements Validator {

    private static final String PASSWORD_PATTERN = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
    
    @Override
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
        String password = (value == null) ? "" : value.toString();

        Pattern pattern = Pattern.compile(PASSWORD_PATTERN);
        Matcher matcher = pattern.matcher(password);

        if (!matcher.matches()) {
            throw new ValidatorException(new FacesMessage(
                FacesMessage.SEVERITY_ERROR,
                "La contraseña debe tener al menos 8 caracteres y contener al menos una mayúscula, una minúscula, un número y un símbolo (@$!%*?&).",
                null
            ));
        }

        // Obtener la confirmación de la contraseña
        UIComponent confirmComponent = (UIComponent) component.getAttributes().get("confirmComponent");
        if (confirmComponent != null) {
            String confirm = (String) confirmComponent.getAttributes().get("value");

            if (!password.equals(confirm)) {
                throw new ValidatorException(new FacesMessage(
                    FacesMessage.SEVERITY_ERROR,
                    "Las contraseñas no coinciden.",
                    null
                ));
            }
        }
    }
}
