package co.edu.unbosque.controller;

import java.io.IOException;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import java.io.InputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;

import co.edu.unbosque.model.entity.Producto;
import co.edu.unbosque.model.service.ProductoService;

@ManagedBean
@SessionScoped
public class ProductoBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8586016263534331593L;
	private ProductoService ps = new ProductoService();
	private List<Producto> listaProducto;
	private Producto productoExistente;
	private Producto productoNuevo;
	private String getIdProducto;
	private String originalFileName;
	private UploadedFile file;
	private String uniqueFileName;

	public ProductoBean() {
		listaProducto = ps.findAll();
	}

	public String crearProducto() {
		productoNuevo = new Producto();
		// ps.create(productoNuevo);
		return "nuevoProducto.xhtml";
	}

	public ArrayList<Producto> productos() {
		ArrayList<Producto> productos = (ArrayList<Producto>) ps.findAll();
		return productos;
	}

	public String guardarnp() {
		if (productoExistente.getPrcioVntaAc() <= productoExistente.getCstoVnta()) {
            FacesContext.getCurrentInstance().addMessage("form:txtPpre",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "El nuevo precio de venta debe ser mayor al costo", null));
            return null;
        }
		ps.update(productoExistente);
		return "listaProductos.xhtml";
	}

	public String crearnp() {
		if (productoNuevo.getCntdadElemnto() <= 0) {
            FacesContext.getCurrentInstance().addMessage("form:txtCant",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "La cantidad debe ser un número positivo.", null));
            return null;
        }
		if (productoNuevo.getCntdadElemnto() > productoNuevo.getStockMxmo()) {
            FacesContext.getCurrentInstance().addMessage("form:txtCant",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "La cantidad no debe superar el maximo del stock.", null));
            return null;
		}
        
        if (productoNuevo.getCstoVnta() >= productoNuevo.getPrcioVntaAc()) {
            FacesContext.getCurrentInstance().addMessage("form:txtCosto",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "El costo de venta debe ser menor al precio de venta AC.", null));
            return null;
        }

        
        if (productoNuevo.getPrcioVntaAn() <= 0) {
            FacesContext.getCurrentInstance().addMessage("form:txtPvan",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "El precio de venta AN debe ser un número positivo.", null));
            return null;
        }

        
        if (productoNuevo.getStockMxmo() <= productoNuevo.getStockMinmo()) {
            FacesContext.getCurrentInstance().addMessage("form:txtSmax",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "El stock máximo debe ser mayor al stock mínimo.", null));
            return null;
        }

        
        if (productoNuevo.getStockMinmo() <= 0) {
            FacesContext.getCurrentInstance().addMessage("form:txtSmin",
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "El stock mínimo debe ser un número positivo.", null));
            return null;
        }
        

		boolean encontrado = true;

		for (Producto producto : listaProducto) {
			if (producto.getCdgoElemnto().equals(getIdProducto)) {
				encontrado = false;
				FacesContext.getCurrentInstance().addMessage("form:txtCod",
	                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "El código ingresado ya se encuentra en uso.", null));
	            

			}
		}
		if (encontrado) {
			productoNuevo.setCdgoElemnto(getIdProducto);
			productoNuevo.setUrl(uniqueFileName);
			ps.update(productoNuevo);
			return "listaProductos.xhtml";
		} else {
			return null;
		}

	}

	public void handleFileUpload(FileUploadEvent event) {
	    UploadedFile uploadedFile = event.getFile();

	    // Ruta relativa para la carpeta de destino dentro del contexto de la aplicación
	    String relativeDestinyPath = "/resources/productos/";

	    try (InputStream input = uploadedFile.getInputStream()) {
	        originalFileName = uploadedFile.getFileName();
	        String fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));

	        // Verificar la extensión del archivo (ejemplo para permitir solo imágenes)
	        if (fileExtension.equalsIgnoreCase(".jpg") || fileExtension.equals(".jpeg") || fileExtension.equalsIgnoreCase(".png")) {
	            uniqueFileName = System.currentTimeMillis() + "_" + originalFileName;

	            // Obtener la ruta real absoluta dentro del contexto de la aplicación
	            String absoluteDestinyPath = FacesContext.getCurrentInstance().getExternalContext()
	                    .getRealPath(relativeDestinyPath);

	            // Combinar la ruta de destino con el nombre de archivo
	            Path fileDestination = Paths.get(absoluteDestinyPath, uniqueFileName);

	            // Copiar el archivo a la carpeta de destino
	            Files.copy(input, fileDestination, StandardCopyOption.REPLACE_EXISTING);
	        } else {
	            // Manejar archivos no permitidos
	            System.out.println("Formato de archivo no válido. Solo se permiten archivos de imagen.");
	        }
	    } catch (IOException e) {
	        // Manejar la excepción
	        System.out.println("No se pudo cargar el archivo.");
	        e.printStackTrace();
	    }
	}
	
//	public void handleFileUpload(FileUploadEvent event) {
//	    UploadedFile uploadedFile = event.getFile();
//
//	    // Ruta relativa para la carpeta de destino dentro del contexto de la aplicación
//	    String relativeDestinyPath = "/resources/productos";
//
//	    try (InputStream input = uploadedFile.getInputStream()) {
//	        originalFileName = uploadedFile.getFileName();
//	        String fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
//
//	        // Verificar la extensión del archivo (ejemplo para permitir solo imágenes)
//	        if (fileExtension.equalsIgnoreCase(".jpg") || fileExtension.equals(".jpeg") || fileExtension.equalsIgnoreCase(".png")) {
//	            String uniqueFileName = System.currentTimeMillis() + "_" + originalFileName;
//
//	            // Obtener la ruta real absoluta dentro del contexto de la aplicación
//	            String absoluteDestinyPath = FacesContext.getCurrentInstance().getExternalContext()
//	                    .getRealPath(relativeDestinyPath);
//
//	            // Combinar la ruta de destino con el nombre de archivo
//	            Path fileDestination = Paths.get(absoluteDestinyPath, uniqueFileName);
//
//	            // Copiar el archivo a la carpeta de destino
//	            Files.copy(input, fileDestination, StandardCopyOption.REPLACE_EXISTING);
//	        } else {
//	            // Manejar archivos no permitidos
//	            System.out.println("Formato de archivo no válido. Solo se permiten archivos de imagen.");
//	        }
//	    } catch (IOException e) {
//	        // Manejar la excepción
//	        System.out.println("No se pudo cargar el archivo.");
//	        e.printStackTrace();
//	    }
//	}
	
//	public void handleFileUpload(FileUploadEvent event) {
//		UploadedFile uploadedFile = event.getFile();
//
//		// Obtener la ruta de la carpeta de destino
//		String destino = "/resources/productos/";
//
//		// Guardar el archivo en la carpeta de destino sin preocuparse por el tipo de
//		// contenido
//		try (InputStream input = uploadedFile.getInputStream()) {
//			System.out.println(uploadedFile.getFileName());
//			// Generar un nombre único para evitar conflictos
//			String nombreArchivo = System.currentTimeMillis() + "_" + uploadedFile.getFileName();
//
//			// Combinar la ruta de destino con el nombre de archivo
//			Path archivoDestino = Paths.get(destino, nombreArchivo);
//			System.out.println(archivoDestino);
//
//			// Copiar el archivo a la carpeta de destino
//			Files.copy(input, archivoDestino, StandardCopyOption.REPLACE_EXISTING);
//		} catch (IOException e) {
//			// Manejar la excepción
//			System.out.println("no se pudo");
//			e.printStackTrace();
//		}
//
//	}

	public String eliminarProducto() {
		ps.delete(productoExistente);
		return null;
	}

	public List<Producto> getListaProducto() {
		return listaProducto;
	}

	public void setListaProducto(List<Producto> listaProducto) {
		this.listaProducto = listaProducto;
	}

	public Producto getProductoExistente() {
		return productoExistente;
	}

	public void setProductoExistente(Producto productoExistente) {
		this.productoExistente = productoExistente;
	}

	public Producto getProductoNuevo() {
		return productoNuevo;
	}

	public void setProductoNuevo(Producto productoNuevo) {
		this.productoNuevo = productoNuevo;
	}

	public String getGetIdProducto() {
		return getIdProducto;
	}

	public void setGetIdProducto(String getIdProducto) {
		this.getIdProducto = getIdProducto;
	}

	public UploadedFile getFile() {
		return file;
	}

	public void setFile(UploadedFile file) {
		this.file = file;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}
	
	

}