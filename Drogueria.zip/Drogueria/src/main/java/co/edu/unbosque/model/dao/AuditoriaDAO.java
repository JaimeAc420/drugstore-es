package co.edu.unbosque.model.dao;

import co.edu.unbosque.model.entity.Auditoria;

public class AuditoriaDAO extends GenericDAO<Auditoria, Integer>{

	public AuditoriaDAO() {
		super(Auditoria.class);
	}

}
