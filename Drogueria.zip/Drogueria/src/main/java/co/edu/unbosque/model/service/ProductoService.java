package co.edu.unbosque.model.service;

import java.util.List;

import co.edu.unbosque.model.dao.ProductoDAO;
import co.edu.unbosque.model.entity.Producto;

public class ProductoService implements Service<Producto, String>{

	private ProductoDAO productodao;
	
	public ProductoService() {
		this.productodao = new ProductoDAO();
	}
	
	@Override
	public void create(Producto objeto) {
		productodao.saveOrUpdate(objeto);
	}

	@Override
	public void update(Producto objeto) {
		productodao.saveOrUpdate(objeto);
	}

	@Override
	public Producto delete(Producto objeto) {
		productodao.delete(objeto);
		return objeto;
	}

	@Override
	public Producto findById(String id) {
		return productodao.get(id);
	}

	@Override
	public List<Producto> findAll() {
		return productodao.findAll();
	}
	

}
