package co.edu.unbosque.model.dao;

import co.edu.unbosque.model.entity.Tipousuario;

public class TipoUsuarioDAO extends GenericDAO<Tipousuario, Short>{

	public TipoUsuarioDAO() {
		super(Tipousuario.class);
		// TODO Auto-generated constructor stub
	}

}
