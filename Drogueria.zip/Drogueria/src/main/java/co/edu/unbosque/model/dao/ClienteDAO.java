package co.edu.unbosque.model.dao;

import co.edu.unbosque.model.entity.Cliente;

public class ClienteDAO extends GenericDAO<Cliente, Integer> {

	public ClienteDAO() {
		super(Cliente.class);
	}

}
