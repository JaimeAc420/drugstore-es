package co.edu.unbosque.model.entity;

import java.io.Serializable;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the auditoria database table.
 * 
 */
@Entity
@Table(name = "auditoria")
public class Auditoria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "accion_audtria")
	private String accionAudtria;

	@Column(name = "address_audtria")
	private String addressAudtria;

	@Column(name = "comentario_audtria")
	private String comentarioAudtria;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "fcha_audtria")
	private Date fchaAudtria;

	@Id
	@Column(name = "id", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@Column(name = "usrio_audtria")
	private String usrioAudtria;

	public Auditoria() {
	}

	public Auditoria(String accionAudtria, String addressAudtria, String comentarioAudtria, Date fchaAudtria,
			String usrioAudtria) {
		super();
		this.accionAudtria = accionAudtria;
		this.addressAudtria = addressAudtria;
		this.comentarioAudtria = comentarioAudtria;
		this.fchaAudtria = fchaAudtria;
		this.usrioAudtria = usrioAudtria;
	}

	public String getAccionAudtria() {
		return this.accionAudtria;
	}

	public void setAccionAudtria(String accionAudtria) {
		this.accionAudtria = accionAudtria;
	}

	public String getAddressAudtria() {
		return this.addressAudtria;
	}

	public void setAddressAudtria(String addressAudtria) {
		this.addressAudtria = addressAudtria;
	}

	public String getComentarioAudtria() {
		return this.comentarioAudtria;
	}

	public void setComentarioAudtria(String comentarioAudtria) {
		this.comentarioAudtria = comentarioAudtria;
	}

	public Date getFchaAudtria() {
		return this.fchaAudtria;
	}

	public void setFchaAudtria(Date fchaAudtria) {
		this.fchaAudtria = fchaAudtria;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsrioAudtria() {
		return this.usrioAudtria;
	}

	public void setUsrioAudtria(String usrioAudtria) {
		this.usrioAudtria = usrioAudtria;
	}

	@Override
	public String toString() {
		return "Auditoria [accionAudtria=" + accionAudtria + ", addressAudtria=" + addressAudtria
				+ ", comentarioAudtria=" + comentarioAudtria + ", fchaAudtria=" + fchaAudtria + ", id=" + id
				+ ", usrioAudtria=" + usrioAudtria + "]";
	}

}