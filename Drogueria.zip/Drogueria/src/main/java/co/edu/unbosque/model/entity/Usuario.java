package co.edu.unbosque.model.entity;

import java.io.Serializable;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;



/**
 * The persistent class for the usuario database table.
 * 
 */
@Entity
@Table(name="usuario", uniqueConstraints = @UniqueConstraint(columnNames = "login"))
public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "login", unique = true, nullable = false)
	private String login;

	@Column(name="apellido_usuario")
	private String apellidoUsuario;

	private String clave;

	private String estado;

	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaUltimaClave;

	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaUltimoIngreso;

	private short intentos;

	@Column(name="nombre_usuario")
	private String nombreUsuario;

	private String nombreCorto;

	private short tipoUsuario;

	public Usuario() {
	}
	
	

	public Usuario(String login, String apellidoUsuario, String clave, String estado, Date fechaUltimaClave,
			Date fechaUltimoIngreso, short intentos, String nombreUsuario, String nombreCorto, short tipoUsuario) {
		super();
		this.login = login;
		this.apellidoUsuario = apellidoUsuario;
		this.clave = clave;
		this.estado = estado;
		this.fechaUltimaClave = fechaUltimaClave;
		this.fechaUltimoIngreso = fechaUltimoIngreso;
		this.intentos = intentos;
		this.nombreUsuario = nombreUsuario;
		this.nombreCorto = nombreCorto;
		this.tipoUsuario = tipoUsuario;
	}



	public String getLogin() {
		return this.login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getApellidoUsuario() {
		return this.apellidoUsuario;
	}

	public void setApellidoUsuario(String apellidoUsuario) {
		this.apellidoUsuario = apellidoUsuario;
	}

	public String getClave() {
		return this.clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getEstado() {
		return this.estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Date getFechaUltimaClave() {
		return this.fechaUltimaClave;
	}

	public void setFechaUltimaClave(Date fechaUltimaClave) {
		this.fechaUltimaClave = fechaUltimaClave;
	}

	public Date getFechaUltimoIngreso() {
		return this.fechaUltimoIngreso;
	}

	public void setFechaUltimoIngreso(Date fechaUltimoIngreso) {
		this.fechaUltimoIngreso = fechaUltimoIngreso;
	}

	public short getIntentos() {
		return this.intentos;
	}

	public void setIntentos(short intentos) {
		this.intentos = intentos;
	}

	public String getNombreUsuario() {
		return this.nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getNombreCorto() {
		return this.nombreCorto;
	}

	public void setNombreCorto(String nombreCorto) {
		this.nombreCorto = nombreCorto;
	}

	public short getTipoUsuario() {
		return this.tipoUsuario;
	}

	public void setTipoUsuario(short tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	@Override
	public String toString() {
		return "Usuario [login=" + login + ", apellidoUsuario=" + apellidoUsuario + ", clave=" + clave + ", estado="
				+ estado + ", fechaUltimaClave=" + fechaUltimaClave + ", fechaUltimoIngreso=" + fechaUltimoIngreso
				+ ", intentos=" + intentos + ", nombreUsuario=" + nombreUsuario + ", nombreCorto=" + nombreCorto
				+ ", tipoUsuario=" + tipoUsuario + "]";
	}
	
	

}