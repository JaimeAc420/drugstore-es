package co.edu.unbosque.model.service;

import java.util.List;

import co.edu.unbosque.model.dao.ClienteDAO;
import co.edu.unbosque.model.entity.Cliente;

public class ClienteService implements Service<Cliente, Integer>{
	
	private ClienteDAO clientedao;

	public ClienteService() {
		this.clientedao = new ClienteDAO();
	}


	@Override
	public void create(Cliente objeto) {
		clientedao.saveOrUpdate(objeto);
	}

	@Override
	public void update(Cliente objeto) {
		clientedao.saveOrUpdate(objeto);
	}

	@Override
	public Cliente delete(Cliente objeto) {
		Cliente clienteAux = objeto;
		clienteAux.setEstado("I");
		clientedao.saveOrUpdate(clienteAux);
		return objeto;
	}

	@Override
	public Cliente findById(Integer id) {
		return clientedao.get(id);
	}

	@Override
	public List<Cliente> findAll() {
		return clientedao.findAll();
	}
	
	public ClienteDAO getClientedao() {
		return clientedao;
	}
	
	public void setClientedao(ClienteDAO clientedao) {
		this.clientedao = clientedao;
	}

}
