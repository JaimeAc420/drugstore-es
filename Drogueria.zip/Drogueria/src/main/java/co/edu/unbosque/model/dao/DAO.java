package co.edu.unbosque.model.dao;

import java.io.Serializable;
import java.util.List;

public interface DAO<T, ID extends Serializable> {
	T create();

	void saveOrUpdate(T entity);

	T get(ID id);

	void delete(T entity);

	List<T> findAll();

}
