package co.edu.unbosque.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import co.edu.unbosque.model.entity.Auditoria;
import co.edu.unbosque.model.entity.Cliente;
import co.edu.unbosque.model.entity.Usuario;
import co.edu.unbosque.model.service.AuditoriaService;
import co.edu.unbosque.model.service.ClienteService;
import co.edu.unbosque.model.service.UsuarioService;

@ManagedBean
@RequestScoped
public class VerClientesBean {
	
	private AuditoriaService audiser = new AuditoriaService();
	private static List<Usuario> usarios = new ArrayList<Usuario>();
	private static Usuario userupdate;
	private static Cliente clienteupdate;
	private Usuario usernew = new Usuario();
	private Cliente clienew = new Cliente();
	private String login = "";
	private String contraseña1 = "";
	private String contraseña2 = "";

	
	public ArrayList<Usuario> usuarios() {
		UsuarioService ususer = new UsuarioService();
		
		ArrayList<Usuario> usuarios = (ArrayList<Usuario>) ususer.findAll();
		return usuarios;
	}
	
	public String regresar() {
		return "verPerfil.xhtml";
	}
	
	
	public String crearUsuario() {
		return "CrearUsuario.xhtml";
	}
	
	public String crearNuevo() {
		
		UsuarioService userser = new UsuarioService();
		ClienteService clienser = new ClienteService();
		Auditoria auditoria = new Auditoria();
		System.out.println(login);
		Usuario aux = userser.findById(login);
		System.out.println(aux);
		if(aux == null) {
			if(contraseña1.equals(contraseña2)) {
//				cliente();
				clienew.setComprasMes(new BigDecimal(0));
				clienew.setCupocredito(new BigDecimal(0));
				clienew.setEstado("A");
				clienew.setPagosMes(new BigDecimal(0));
				clienew.setSaldoActual(new BigDecimal(0));
//				usuario();
				usernew.setEstado("A");
				usernew.setFechaUltimaClave(new Date());
				usernew.setIntentos((short)3);
//				auditoria();
				auditoria.setAccionAudtria("C");
				auditoria.setAddressAudtria("Registro cliente CrearUsuario.xhtml");
				auditoria.setFchaAudtria(new Date());
				
				usernew.setLogin(login);
				usernew.setClave(userser.codificarContasena(contraseña1));
				usernew.setNombreCorto(login);
				clienew.setNombre(usernew.getLogin());
				auditoria.setUsrioAudtria("admin");
				auditoria.setComentarioAudtria(usernew.getNombreCorto()+" se ha agregado en el sistema");
				clienser.create(clienew);
				userser.create(usernew);
				audiser.create(auditoria);
				return "verPerfil.xhtml";
			}else {
				System.out.println("contraseña no coincide");
				 FacesContext.getCurrentInstance().addMessage(null,
		                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "Las contraseñas no coinciden."));
		            return null; 
			}
		}else {
			System.out.println("El user ya existe");
			FacesContext.getCurrentInstance().addMessage(null, 
	                new FacesMessage(FacesMessage.SEVERITY_ERROR, "Error", "El usuario ya existe. Por favor, elige otro login."));
		}
		return null;
	}
	
	public void eliminar(String login) {
		UsuarioService userser = new UsuarioService();
		ClienteService clienser = new ClienteService();
		userupdate = userser.findById(login);
		System.out.println(userupdate);
		ArrayList<Cliente> clientes = (ArrayList<Cliente>)clienser.findAll();
		for (Cliente  i: clientes) {
			if(i.getNombre().equals(userupdate.getLogin()) ) {
				clienteupdate = i;
				System.out.println(clienteupdate);
				break;
			}
		}
		userupdate.setEstado("I");
		clienteupdate.setEstado("I");
		userser.update(userupdate);
		clienser.update(clienteupdate);
		Auditoria audi = new Auditoria("E", "E VerPerfil.xhtml", userupdate.getLogin()+" ha sido eliminado", new Date(), "admin");
		audiser.create(audi);

	}
	
	
	public void guardar() {
		ClienteService cliser = new ClienteService();
		UsuarioService userser = new UsuarioService();
		if(userupdate.getEstado().equals("A")) {
			userupdate.setIntentos((short)3);
		}else if(userupdate.getEstado().equals("I")) {
			userupdate.setIntentos((short)3);
		}else if(userupdate.getEstado().equals("B")){
			userupdate.setIntentos((short)0);
		}
		clienteupdate.setEstado(userupdate.getEstado());
		
		cliser.update(clienteupdate);
		userser.update(userupdate);
		Auditoria audi = new Auditoria("A", "A EditarUsuario.xhtml", userupdate.getLogin()+" ha sido editado", new Date(), "admin");
		audiser.create(audi);
		
	}
	
	public String editarUsuario(String login) {
		UsuarioService userser = new UsuarioService();
		ClienteService clienser = new ClienteService();
		userupdate = userser.findById(login);
		System.out.println(userupdate);
		ArrayList<Cliente> clientes = (ArrayList<Cliente>)clienser.findAll();
		for (Cliente  i: clientes) {
			if(i.getNombre().equals(userupdate.getLogin()) ) {
				clienteupdate = i;
				System.out.println(clienteupdate);
				return "EditarUsuario.xhtml";
			}else {
				clienteupdate = null;
			}
		}
		return "EditarUsuario.xhtml";
	}
	
	
	
	public Usuario getUserupdate() {
		return userupdate;
	}
	
	
	
	public void setUserupdate(Usuario userupdate) {
		this.userupdate = userupdate;
	}
	
	
	
	public Cliente getClienteupdate() {
		return clienteupdate;
	}
	
	
	
	public void setClienteupdate(Cliente clienteupdate) {
		this.clienteupdate = clienteupdate;
	}
	


	public AuditoriaService getAudiser() {
		return audiser;
	}


	public void setAudiser(AuditoriaService audiser) {
		this.audiser = audiser;
	}

	public static List<Usuario> getUsarios() {
		return usarios;
	}


	public static void setUsarios(List<Usuario> usarios) {
		VerClientesBean.usarios = usarios;
	}


	public Usuario getUsernew() {
		return usernew;
	}

	public void setUsernew(Usuario usernew) {
		this.usernew = usernew;
	}

	public Cliente getClienew() {
		return clienew;
	}

	public void setClienew(Cliente clienew) {
		this.clienew = clienew;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getContraseña1() {
		return contraseña1;
	}

	public void setContraseña1(String contraseña1) {
		this.contraseña1 = contraseña1;
	}

	public String getContraseña2() {
		return contraseña2;
	}

	public void setContraseña2(String contraseña2) {
		this.contraseña2 = contraseña2;
	}
	
	
	
	
	
	
	
	
}
