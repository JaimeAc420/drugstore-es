package co.edu.unbosque.controller;

public class Prueba {
	public static void main(String[] args) {
		Reporte r = new Reporte();
		r.generarReporte();
	}

}
