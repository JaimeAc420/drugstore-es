package co.edu.unbosque.model.service;

import java.util.List;

import co.edu.unbosque.model.dao.AuditoriaDAO;
import co.edu.unbosque.model.entity.Auditoria;

public class AuditoriaService implements Service<Auditoria, Integer>{

	private AuditoriaDAO auditoriadao;
	
	public AuditoriaService() {
		this.auditoriadao = new AuditoriaDAO();
	}
	
	@Override
	public void create(Auditoria objeto) {
		auditoriadao.saveOrUpdate(objeto);
	}

	@Override
	public void update(Auditoria objeto) {
		auditoriadao.saveOrUpdate(objeto);
	}

	@Override
	public Auditoria delete(Auditoria objeto) {
		auditoriadao.delete(objeto);
		return objeto;
	}

	@Override
	public Auditoria findById(Integer id) {
		return auditoriadao.get(id);
	}

	@Override
	public List<Auditoria> findAll() {
		return auditoriadao.findAll();
	}

}
