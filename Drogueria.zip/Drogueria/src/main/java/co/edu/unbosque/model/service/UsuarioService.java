package co.edu.unbosque.model.service;

import java.util.List;

import co.edu.unbosque.model.dao.UsuarioDAO;
import co.edu.unbosque.model.entity.Usuario;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UsuarioService implements Service<Usuario, String> {

	private UsuarioDAO usuariodao;

	public UsuarioService() {
		this.usuariodao = new UsuarioDAO();
	}

	@Override
	public void create(Usuario objeto) {
		usuariodao.saveOrUpdate(objeto);
	}

	@Override
	public void update(Usuario objeto) {
		usuariodao.saveOrUpdate(objeto);
	}

	@Override
	public Usuario delete(Usuario objeto) {
		Usuario usuarioaux = objeto;
		usuarioaux.setEstado("I");
		usuariodao.saveOrUpdate(usuarioaux);
		return objeto;
	}

	@Override
	public Usuario findById(String id) {
		return usuariodao.get(id);
	}

	@Override
	public List<Usuario> findAll() {
		return usuariodao.findAll();
	}

//	public String verificarTipoUsuario(String login, String clave) {
//		Usuario usuario = findById(login);
//		if (usuario != null && codificarContasena(usuario.getClave()).equals(clave)) {
//			if (usuario.getTipoUsuario() == 1) {
//				return "admin";
//			} else {
//				return "cliente";
//			}
//		} else {
//			return "error";
//		}
//	}

	public String codificarContasena(String contrasena) {
		try {

			MessageDigest md = MessageDigest.getInstance("SHA-1");

			md.update(contrasena.getBytes());

			byte[] digest = md.digest();

			StringBuilder codedContra = new StringBuilder();
			for (byte b : digest) {
				codedContra.append(String.format("%02x", b));
			}

			return codedContra.toString();

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}

	}
}
