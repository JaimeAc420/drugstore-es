package co.edu.unbosque.model.dao;

import co.edu.unbosque.model.entity.Producto;

public class ProductoDAO extends GenericDAO<Producto, String>{

	public ProductoDAO() {
		super(Producto.class);
		// TODO Auto-generated constructor stub
	}

}
